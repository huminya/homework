#encoding: utf-8

class HiExampleNavigator < Lazyman::Navigator
end
