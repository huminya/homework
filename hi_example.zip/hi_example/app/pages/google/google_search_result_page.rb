#encoding: utf-8
class GoogleSearchResultPage < HiExamplePage
	h3 'first_result', index: 0
end
