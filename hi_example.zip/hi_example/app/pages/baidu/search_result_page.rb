#encoding: utf-8
class SearchResultPage < HiExamplePage
	h3 'first_result', index: 0
end
